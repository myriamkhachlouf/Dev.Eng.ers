<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* jobs.html.twig */
class __TwigTemplate_f206d10cb02b581d4d49dbc80f136c27a95c8403615d1d748d1bfc6091e8d159 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "jobs.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "jobs.html.twig"));

        // line 1
        echo "<!DOCTYPE HTML>
<html>
<head>
    <title>PHPJabbers.com | Free Job Agency Website Template</title>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\" />
    <link rel=\"stylesheet\" href=\"assets/bootstrap/css/bootstrap.min.css\" />
    <link rel=\"stylesheet\" href=\"assets/css/main.css\" />
    <noscript><link rel=\"stylesheet\" href=\"assets/css/noscript.css\" /></noscript>
</head>
<body class=\"is-preload\">

<!-- Wrapper -->
<div id=\"wrapper\">

    <!-- Header -->
    <header id=\"header\" class=\"alt\">
        <a href=\"base.html.twig\" class=\"logo\"><strong>Job Agency</strong> <span>Website</span></a>
        <nav>
            <a href=\"#menu\">Menu</a>
        </nav>
    </header>

    <!-- Menu -->
    <nav id=\"menu\">
        <ul class=\"links\">
            <li> <a href=\"/first\">Home </a> </li>

            <li class=\"active\"> <a href=\"/jobs\">Jobs</a> </li>

            <li> <a href=\"/blog\">Blog</a> </li>

            <li> <a href=\"/about\">About Us</a> </li>

            <li><a href=\"/team\">Team</a></li>

            <li><a href=\"/testimonials\">Testimonials</a></li>

            <li><a href=\"/terms\">Terms</a></li>

            <li><a href=\"/contact\">Contact Us</a></li>
        </ul>
    </nav>

    <!-- Main -->
    <div id=\"main\" class=\"alt\">

        <!-- One -->
        <section id=\"one\">
            <div class=\"inner\">
                <header class=\"major\">
                    <h1>Jobs</h1>
                </header>
            </div>
        </section>

        <section>
            <div class=\"inner\">
                <form method=\"post\" action=\"#\">
                    <div class=\"fields\">
                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Type</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Contract (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Full time (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Internship (5)</small>
                                </label>
                            </div>
                        </div>

                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Category</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Accounting / Finance / Insurance Jobs (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Accounting / Finance / Insurance Jobs (5)</small>
                                </label>
                            </div>
                        </div>

                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Career levels</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Entry Level (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Entry Level (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Entry Level (5)</small>
                                </label>
                            </div>
                        </div>

                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Years of experience</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>&lt; 1 (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>&lt; 1 (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>&lt; 1 (5)</small>
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- Featured Jobs -->
        <section class=\"tiles\">
            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-4-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-5-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-6-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"job-details.html.twig\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>
        </section>

    </div>

    <!-- Footer -->
    <footer id=\"footer\">
        <div class=\"inner\">
            <ul class=\"icons\">
                <li><a href=\"#\" class=\"icon alt fa-twitter\"><span class=\"label\">Twitter</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-facebook\"><span class=\"label\">Facebook</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-instagram\"><span class=\"label\">Instagram</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-linkedin\"><span class=\"label\">LinkedIn</span></a></li>
            </ul>
            <ul class=\"copyright\">
                <li>Copyright © 2020 Company Name - Template by:</li>
                <li> <a href=\"https://www.phpjabbers.com/\">PHPJabbers.com</a></li>
            </ul>
        </div>
    </footer>

</div>

<!-- Scripts -->
<script src=\"assets/js/jquery.min.js\"></script>
<script src=\"assets/bootstrap/js/bootstrap.bundle.min.js\"></script>
<script src=\"assets/js/jquery.scrolly.min.js\"></script>
<script src=\"assets/js/jquery.scrollex.min.js\"></script>
<script src=\"assets/js/browser.min.js\"></script>
<script src=\"assets/js/breakpoints.min.js\"></script>
<script src=\"assets/js/util.js\"></script>
<script src=\"assets/js/main.js\"></script>

</body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "jobs.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE HTML>
<html>
<head>
    <title>PHPJabbers.com | Free Job Agency Website Template</title>
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\" />
    <link rel=\"stylesheet\" href=\"assets/bootstrap/css/bootstrap.min.css\" />
    <link rel=\"stylesheet\" href=\"assets/css/main.css\" />
    <noscript><link rel=\"stylesheet\" href=\"assets/css/noscript.css\" /></noscript>
</head>
<body class=\"is-preload\">

<!-- Wrapper -->
<div id=\"wrapper\">

    <!-- Header -->
    <header id=\"header\" class=\"alt\">
        <a href=\"base.html.twig\" class=\"logo\"><strong>Job Agency</strong> <span>Website</span></a>
        <nav>
            <a href=\"#menu\">Menu</a>
        </nav>
    </header>

    <!-- Menu -->
    <nav id=\"menu\">
        <ul class=\"links\">
            <li> <a href=\"/first\">Home </a> </li>

            <li class=\"active\"> <a href=\"/jobs\">Jobs</a> </li>

            <li> <a href=\"/blog\">Blog</a> </li>

            <li> <a href=\"/about\">About Us</a> </li>

            <li><a href=\"/team\">Team</a></li>

            <li><a href=\"/testimonials\">Testimonials</a></li>

            <li><a href=\"/terms\">Terms</a></li>

            <li><a href=\"/contact\">Contact Us</a></li>
        </ul>
    </nav>

    <!-- Main -->
    <div id=\"main\" class=\"alt\">

        <!-- One -->
        <section id=\"one\">
            <div class=\"inner\">
                <header class=\"major\">
                    <h1>Jobs</h1>
                </header>
            </div>
        </section>

        <section>
            <div class=\"inner\">
                <form method=\"post\" action=\"#\">
                    <div class=\"fields\">
                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Type</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Contract (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Full time (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Internship (5)</small>
                                </label>
                            </div>
                        </div>

                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Category</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Accounting / Finance / Insurance Jobs (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Accounting / Finance / Insurance Jobs (5)</small>
                                </label>
                            </div>
                        </div>

                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Career levels</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Entry Level (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Entry Level (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>Entry Level (5)</small>
                                </label>
                            </div>
                        </div>

                        <div class=\"field quarter\">
                            <h5 style=\"margin-bottom: 15px\">Years of experience</h5>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>&lt; 1 (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>&lt; 1 (5)</small>
                                </label>
                            </div>

                            <div>
                                <label>
                                    <input type=\"checkbox\">

                                    <small>&lt; 1 (5)</small>
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- Featured Jobs -->
        <section class=\"tiles\">
            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-4-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-5-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/product-6-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"job-details.html.twig\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>
        </section>

    </div>

    <!-- Footer -->
    <footer id=\"footer\">
        <div class=\"inner\">
            <ul class=\"icons\">
                <li><a href=\"#\" class=\"icon alt fa-twitter\"><span class=\"label\">Twitter</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-facebook\"><span class=\"label\">Facebook</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-instagram\"><span class=\"label\">Instagram</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-linkedin\"><span class=\"label\">LinkedIn</span></a></li>
            </ul>
            <ul class=\"copyright\">
                <li>Copyright © 2020 Company Name - Template by:</li>
                <li> <a href=\"https://www.phpjabbers.com/\">PHPJabbers.com</a></li>
            </ul>
        </div>
    </footer>

</div>

<!-- Scripts -->
<script src=\"assets/js/jquery.min.js\"></script>
<script src=\"assets/bootstrap/js/bootstrap.bundle.min.js\"></script>
<script src=\"assets/js/jquery.scrolly.min.js\"></script>
<script src=\"assets/js/jquery.scrollex.min.js\"></script>
<script src=\"assets/js/browser.min.js\"></script>
<script src=\"assets/js/breakpoints.min.js\"></script>
<script src=\"assets/js/util.js\"></script>
<script src=\"assets/js/main.js\"></script>

</body>
</html>", "jobs.html.twig", "D:\\wamp64\\www\\PI\\templates\\jobs.html.twig");
    }
}
