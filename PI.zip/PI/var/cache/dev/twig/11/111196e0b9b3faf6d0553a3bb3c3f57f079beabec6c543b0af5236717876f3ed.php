<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_d81d5ec5f298644c4e5676bd644c848d762a40c2e4e3b7ed0798ad634b3257a2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'stylesheet' => [$this, 'block_stylesheet'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE HTML>
<html>


<head>
    ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "
    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\" />
    <link rel=\"stylesheet\" href=\"assets/bootstrap/css/bootstrap.min.css\" />
    <link rel=\"stylesheet\" href=\"assets/css/main.css\" />
    <noscript><link rel=\"stylesheet\" href=\"assets/css/noscript.css\" /></noscript>
    ";
        // line 15
        $this->displayBlock('stylesheet', $context, $blocks);
        // line 16
        echo "</head>
<body class=\"is-preload\">

<!-- Wrapper -->
<div id=\"wrapper\">

    <!-- Header -->
    <header id=\"header\" class=\"alt\">
        <a href=\"/first\" class=\"logo\"><strong>Job Agency</strong> <span>Website</span></a>
        <nav>
            <a href=\"#menu\">Menu</a>
        </nav>
    </header>

    <!-- Menu -->
    <nav id=\"menu\">
        <ul class=\"links\">
            <li class=\"active\"> <a href=\"/first\">Home </a> </li>

            <li> <a href=\"/jobs\">Jobs</a> </li>

            <li> <a href=\"/blog\">Blog</a> </li>

            <li> <a href=\"/about\">About Us</a> </li>

            <li><a href=\"/team\">Team</a></li>

            <li><a href=\"/testimonials\">Testimonials</a></li>

            <li><a href=\"/terms\">Terms</a></li>

            <li><a href=\"/contact\">Contact Us</a></li>
        </ul>
    </nav>

    <!-- Banner -->
    <section id=\"banner\" class=\"major\">
        <div class=\"inner\">
            <header class=\"major\">
                <h1>Lorem ipsum dolor sit amet isicing</h1>
            </header>
            <div class=\"content\">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos, libero!</p>
                <ul class=\"actions\">
                    <li><a href=\"/contact\" class=\"button next scrolly\">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </section>

    <!-- Main -->
    <div id=\"main\">


        <!-- About us -->
        <section>
            <div class=\"inner\">
                <header class=\"major\">
                    <h2>About us</h2>
                </header>
                <p>Nullam et orci eu lorem consequat tincidunt vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus pharetra. Pellentesque condimentum sem. In efficitur ligula tate urna. Maecenas laoreet massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus amet pharetra et feugiat tempus.</p>
                <ul class=\"actions\">
                    <li><a href=\"/about\" class=\"button next\">Read more</a></li>
                </ul>
            </div>
        </section>

        <!-- Featured Jobs -->
        <section class=\"tiles\">
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobs\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-4-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-5-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-6-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>
        </section>

        <!-- Testimonials -->
        <section>
            <div class=\"inner\">
                <header class=\"major\">
                    <h2>Testimonials</h2>
                </header>
                <div class=\"row\">
                    <div class=\"col-6\">
                        <p><em>\"Nullam et orci eu lorem consequat tincidunt vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus pharetra. Pellentesque condimentum sem. In efficitur ligula tate urna. Maecenas laoreet massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt.\"</em></p>
                        <p><strong>- John Doe</strong></p>

                    </div>

                    <div class=\"col-6\">
                        <p><em>\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores temporibus dolorum minus repudiandae, eaque error corporis aliquam, architecto amet itaque nobis. Omnis itaque est dolore, a nostrum numquam. Quae, facilis.\"</em></p>
                        <p><strong>- Jack Smith</strong></p>
                    </div>
                </div>
                <ul class=\"actions\">
                    <li><a href=\"/testimonials\" class=\"button next\">Read more</a></li>
                </ul>
            </div>
        </section>

        <!-- Blog Posts -->
        <section class=\"tiles\">
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/blog-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>
                <header class=\"major\">
                    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

                    <p><br> <span>John Doe</span> | <span>12/06/2020 10:30 </span> | <span>114</span></p>

                    <div class=\"major-actions\">
                        <a href=\"/blogdetails\" class=\"button small next scrolly\">Read Blog</a>
                    </div>
                </header>
            </article>
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/blog-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>
                <header class=\"major\">
                    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

                    <p><br> <span>John Doe</span> | <span>12/06/2020 10:30 </span> | <span>114</span></p>

                    <div class=\"major-actions\">
                        <a href=\"/blogdetails\" class=\"button small next scrolly\">Read Blog</a>
                    </div>
                </header>
            </article>
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/blog-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>
                <header class=\"major\">
                    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

                    <p><br> <span>John Doe</span> | <span>12/06/2020 10:30 </span> | <span>114</span></p>

                    <div class=\"major-actions\">
                        <a href=\"/blogdetails\" class=\"button small next scrolly\">Read Blog</a>
                    </div>
                </header>
            </article>
        </section>
    </div>

    <!-- Footer -->
    <footer id=\"footer\">
        <div class=\"inner\">
            <ul class=\"icons\">
                <li><a href=\"#\" class=\"icon alt fa-twitter\"><span class=\"label\">Twitter</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-facebook\"><span class=\"label\">Facebook</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-instagram\"><span class=\"label\">Instagram</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-linkedin\"><span class=\"label\">LinkedIn</span></a></li>
            </ul>
            <ul class=\"copyright\">
                <li>Copyright © 2020 Company Name - Template by:</li>
                <li> <a href=\"https://www.phpjabbers.com/\">PHPJabbers.com</a></li>
            </ul>
        </div>
    </footer>

</div>

<!-- Scripts -->
<script src=\"assets/js/jquery.min.js\"></script>
<script src=\"assets/bootstrap/js/bootstrap.bundle.min.js\"></script>
<script src=\"assets/js/jquery.scrolly.min.js\"></script>
<script src=\"assets/js/jquery.scrollex.min.js\"></script>
<script src=\"assets/js/browser.min.js\"></script>
<script src=\"assets/js/breakpoints.min.js\"></script>
<script src=\"assets/js/util.js\"></script>
<script src=\"assets/js/main.js\"></script>

</body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 6
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "    <title>PHPJabbers.com | Free Job Agency Website Template</title>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 15
    public function block_stylesheet($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheet"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "stylesheet"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  415 => 15,  404 => 7,  394 => 6,  64 => 16,  62 => 15,  54 => 9,  52 => 6,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE HTML>
<html>


<head>
    {% block title%}
    <title>PHPJabbers.com | Free Job Agency Website Template</title>
    {%endblock %}

    <meta charset=\"utf-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\" />
    <link rel=\"stylesheet\" href=\"assets/bootstrap/css/bootstrap.min.css\" />
    <link rel=\"stylesheet\" href=\"assets/css/main.css\" />
    <noscript><link rel=\"stylesheet\" href=\"assets/css/noscript.css\" /></noscript>
    {% block stylesheet %}{%endblock %}
</head>
<body class=\"is-preload\">

<!-- Wrapper -->
<div id=\"wrapper\">

    <!-- Header -->
    <header id=\"header\" class=\"alt\">
        <a href=\"/first\" class=\"logo\"><strong>Job Agency</strong> <span>Website</span></a>
        <nav>
            <a href=\"#menu\">Menu</a>
        </nav>
    </header>

    <!-- Menu -->
    <nav id=\"menu\">
        <ul class=\"links\">
            <li class=\"active\"> <a href=\"/first\">Home </a> </li>

            <li> <a href=\"/jobs\">Jobs</a> </li>

            <li> <a href=\"/blog\">Blog</a> </li>

            <li> <a href=\"/about\">About Us</a> </li>

            <li><a href=\"/team\">Team</a></li>

            <li><a href=\"/testimonials\">Testimonials</a></li>

            <li><a href=\"/terms\">Terms</a></li>

            <li><a href=\"/contact\">Contact Us</a></li>
        </ul>
    </nav>

    <!-- Banner -->
    <section id=\"banner\" class=\"major\">
        <div class=\"inner\">
            <header class=\"major\">
                <h1>Lorem ipsum dolor sit amet isicing</h1>
            </header>
            <div class=\"content\">
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos, libero!</p>
                <ul class=\"actions\">
                    <li><a href=\"/contact\" class=\"button next scrolly\">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </section>

    <!-- Main -->
    <div id=\"main\">


        <!-- About us -->
        <section>
            <div class=\"inner\">
                <header class=\"major\">
                    <h2>About us</h2>
                </header>
                <p>Nullam et orci eu lorem consequat tincidunt vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus pharetra. Pellentesque condimentum sem. In efficitur ligula tate urna. Maecenas laoreet massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt. Vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus amet pharetra et feugiat tempus.</p>
                <ul class=\"actions\">
                    <li><a href=\"/about\" class=\"button next\">Read more</a></li>
                </ul>
            </div>
        </section>

        <!-- Featured Jobs -->
        <section class=\"tiles\">
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobs\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-4-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-5-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>

            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/product-6-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>

                <header class=\"major\">
                    <p>
                        <i class=\"fa fa-calendar\"></i> 15-06-2020 &nbsp;&nbsp;
                        <i class=\"fa fa-file\"></i> Contract &nbsp;&nbsp;
                        <i class=\"fa fa-map-marker\"></i> London
                    </p>

                    <h3>Lorem ipsum dolor sit</h3>

                    <p><strong>\$60 000</strong></p>

                    <p> Medical / Health Jobs</p>
                    <p> BMI Kings Park Hospital</p>

                    <div class=\"major-actions\">
                        <a href=\"/jobdetails\" class=\"button small next\">View Job</a>
                    </div>
                </header>
            </article>
        </section>

        <!-- Testimonials -->
        <section>
            <div class=\"inner\">
                <header class=\"major\">
                    <h2>Testimonials</h2>
                </header>
                <div class=\"row\">
                    <div class=\"col-6\">
                        <p><em>\"Nullam et orci eu lorem consequat tincidunt vivamus et sagittis libero. Mauris aliquet magna magna sed nunc rhoncus pharetra. Pellentesque condimentum sem. In efficitur ligula tate urna. Maecenas laoreet massa vel lacinia pellentesque lorem ipsum dolor. Nullam et orci eu lorem consequat tincidunt.\"</em></p>
                        <p><strong>- John Doe</strong></p>

                    </div>

                    <div class=\"col-6\">
                        <p><em>\"Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores temporibus dolorum minus repudiandae, eaque error corporis aliquam, architecto amet itaque nobis. Omnis itaque est dolore, a nostrum numquam. Quae, facilis.\"</em></p>
                        <p><strong>- Jack Smith</strong></p>
                    </div>
                </div>
                <ul class=\"actions\">
                    <li><a href=\"/testimonials\" class=\"button next\">Read more</a></li>
                </ul>
            </div>
        </section>

        <!-- Blog Posts -->
        <section class=\"tiles\">
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/blog-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>
                <header class=\"major\">
                    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

                    <p><br> <span>John Doe</span> | <span>12/06/2020 10:30 </span> | <span>114</span></p>

                    <div class=\"major-actions\">
                        <a href=\"/blogdetails\" class=\"button small next scrolly\">Read Blog</a>
                    </div>
                </header>
            </article>
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/blog-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>
                <header class=\"major\">
                    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

                    <p><br> <span>John Doe</span> | <span>12/06/2020 10:30 </span> | <span>114</span></p>

                    <div class=\"major-actions\">
                        <a href=\"/blogdetails\" class=\"button small next scrolly\">Read Blog</a>
                    </div>
                </header>
            </article>
            <article>
\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t<img src=\"images/blog-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t</span>
                <header class=\"major\">
                    <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

                    <p><br> <span>John Doe</span> | <span>12/06/2020 10:30 </span> | <span>114</span></p>

                    <div class=\"major-actions\">
                        <a href=\"/blogdetails\" class=\"button small next scrolly\">Read Blog</a>
                    </div>
                </header>
            </article>
        </section>
    </div>

    <!-- Footer -->
    <footer id=\"footer\">
        <div class=\"inner\">
            <ul class=\"icons\">
                <li><a href=\"#\" class=\"icon alt fa-twitter\"><span class=\"label\">Twitter</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-facebook\"><span class=\"label\">Facebook</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-instagram\"><span class=\"label\">Instagram</span></a></li>
                <li><a href=\"#\" class=\"icon alt fa-linkedin\"><span class=\"label\">LinkedIn</span></a></li>
            </ul>
            <ul class=\"copyright\">
                <li>Copyright © 2020 Company Name - Template by:</li>
                <li> <a href=\"https://www.phpjabbers.com/\">PHPJabbers.com</a></li>
            </ul>
        </div>
    </footer>

</div>

<!-- Scripts -->
<script src=\"assets/js/jquery.min.js\"></script>
<script src=\"assets/bootstrap/js/bootstrap.bundle.min.js\"></script>
<script src=\"assets/js/jquery.scrolly.min.js\"></script>
<script src=\"assets/js/jquery.scrollex.min.js\"></script>
<script src=\"assets/js/browser.min.js\"></script>
<script src=\"assets/js/breakpoints.min.js\"></script>
<script src=\"assets/js/util.js\"></script>
<script src=\"assets/js/main.js\"></script>

</body>
</html>", "base.html.twig", "D:\\wamp64\\www\\PI\\templates\\base.html.twig");
    }
}
