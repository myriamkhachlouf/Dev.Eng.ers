<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* blog.html.twig */
class __TwigTemplate_c420e46c7d4f3bb329ec5411753067971624d6c9cb726b099b9c388e511dea93 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "blog.html.twig"));

        // line 1
        echo "<!DOCTYPE HTML>
<html>
\t<head>
\t\t<title>PHPJabbers.com | Free Job Agency Website Template</title>
\t\t<meta charset=\"utf-8\" />
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\" />
\t\t<link rel=\"stylesheet\" href=\"assets/bootstrap/css/bootstrap.min.css\" />
\t\t<link rel=\"stylesheet\" href=\"assets/css/main.css\" />
\t\t<noscript><link rel=\"stylesheet\" href=\"assets/css/noscript.css\" /></noscript>
\t</head>
\t<body class=\"is-preload\">

\t\t<!-- Wrapper -->
\t\t\t<div id=\"wrapper\">

\t\t\t\t<!-- Header -->
\t\t\t\t<header id=\"header\" class=\"alt\">
\t\t\t\t\t<a href=\"base.html.twig\" class=\"logo\"><strong>Job Agency</strong> <span>Website</span></a>
\t\t\t\t\t<nav>
\t\t\t\t\t\t<a href=\"#menu\">Menu</a>
\t\t\t\t\t</nav>
\t\t\t\t</header>

\t\t\t\t<!-- Menu -->
\t\t\t\t<nav id=\"menu\">
\t\t\t\t\t<ul class=\"links\">
\t\t                <li> <a href=\"/first\">Home </a> </li>

\t\t                <li> <a href=\"/jobs\">Jobs</a> </li>

\t\t                <li class=\"active\"> <a href=\"/blog\">Blog</a> </li>

\t\t                <li> <a href=\"/about\">About Us</a> </li>

\t\t                <li><a href=\"/team\">Team</a></li>

\t\t                <li><a href=\"/testimonials\">Testimonials</a></li>
\t\t                
\t\t                <li><a href=\"/terms\">Terms</a></li>

\t\t                <li><a href=\"/contact\">Contact Us</a></li>
            \t\t</ul>
\t\t\t\t</nav>

\t\t\t\t<!-- Main -->
\t\t\t\t\t<div id=\"main\" class=\"alt\">

\t\t\t\t\t\t<!-- One -->
\t\t\t\t\t\t\t<section id=\"one\">
\t\t\t\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h1>Blog</h1>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</section>

\t\t\t\t\t\t\t<!-- Featured Products -->
\t\t\t\t\t\t\t<section class=\"tiles\">
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-4-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-5-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-6-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t</section>

\t\t\t\t\t</div>

\t\t\t\t<!-- Footer -->
\t\t\t\t<footer id=\"footer\">
\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t\t<ul class=\"icons\">
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-twitter\"><span class=\"label\">Twitter</span></a></li>
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-facebook\"><span class=\"label\">Facebook</span></a></li>
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-instagram\"><span class=\"label\">Instagram</span></a></li>
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-linkedin\"><span class=\"label\">LinkedIn</span></a></li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<ul class=\"copyright\">
\t\t\t\t\t\t\t<li>Copyright © 2020 Company Name - Template by:</li>
\t\t\t\t\t\t\t<li> <a href=\"https://www.phpjabbers.com/\">PHPJabbers.com</a></li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</footer>

\t\t\t</div>

\t\t<!-- Scripts -->
\t\t\t<script src=\"assets/js/jquery.min.js\"></script>
\t\t\t<script src=\"assets/bootstrap/js/bootstrap.bundle.min.js\"></script>
\t\t\t<script src=\"assets/js/jquery.scrolly.min.js\"></script>
\t\t\t<script src=\"assets/js/jquery.scrollex.min.js\"></script>
\t\t\t<script src=\"assets/js/browser.min.js\"></script>
\t\t\t<script src=\"assets/js/breakpoints.min.js\"></script>
\t\t\t<script src=\"assets/js/util.js\"></script>
\t\t\t<script src=\"assets/js/main.js\"></script>

\t</body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE HTML>
<html>
\t<head>
\t\t<title>PHPJabbers.com | Free Job Agency Website Template</title>
\t\t<meta charset=\"utf-8\" />
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, user-scalable=no\" />
\t\t<link rel=\"stylesheet\" href=\"assets/bootstrap/css/bootstrap.min.css\" />
\t\t<link rel=\"stylesheet\" href=\"assets/css/main.css\" />
\t\t<noscript><link rel=\"stylesheet\" href=\"assets/css/noscript.css\" /></noscript>
\t</head>
\t<body class=\"is-preload\">

\t\t<!-- Wrapper -->
\t\t\t<div id=\"wrapper\">

\t\t\t\t<!-- Header -->
\t\t\t\t<header id=\"header\" class=\"alt\">
\t\t\t\t\t<a href=\"base.html.twig\" class=\"logo\"><strong>Job Agency</strong> <span>Website</span></a>
\t\t\t\t\t<nav>
\t\t\t\t\t\t<a href=\"#menu\">Menu</a>
\t\t\t\t\t</nav>
\t\t\t\t</header>

\t\t\t\t<!-- Menu -->
\t\t\t\t<nav id=\"menu\">
\t\t\t\t\t<ul class=\"links\">
\t\t                <li> <a href=\"/first\">Home </a> </li>

\t\t                <li> <a href=\"/jobs\">Jobs</a> </li>

\t\t                <li class=\"active\"> <a href=\"/blog\">Blog</a> </li>

\t\t                <li> <a href=\"/about\">About Us</a> </li>

\t\t                <li><a href=\"/team\">Team</a></li>

\t\t                <li><a href=\"/testimonials\">Testimonials</a></li>
\t\t                
\t\t                <li><a href=\"/terms\">Terms</a></li>

\t\t                <li><a href=\"/contact\">Contact Us</a></li>
            \t\t</ul>
\t\t\t\t</nav>

\t\t\t\t<!-- Main -->
\t\t\t\t\t<div id=\"main\" class=\"alt\">

\t\t\t\t\t\t<!-- One -->
\t\t\t\t\t\t\t<section id=\"one\">
\t\t\t\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h1>Blog</h1>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</section>

\t\t\t\t\t\t\t<!-- Featured Products -->
\t\t\t\t\t\t\t<section class=\"tiles\">
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-1-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-2-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-3-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-4-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-5-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t\t<article>
\t\t\t\t\t\t\t\t\t<span class=\"image\">
\t\t\t\t\t\t\t\t\t\t<img src=\"images/blog-6-720x480.jpg\" alt=\"\" />
\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t<header class=\"major\">
\t\t\t\t\t\t\t\t\t\t<h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit hic</h3>

\t\t\t\t\t\t\t\t\t\t<p>John Doe  &nbsp;/&nbsp;  12/06/2020 10:30  &nbsp;/&nbsp;  114</p>

\t\t\t\t\t\t\t\t\t\t<div class=\"major-actions\">
\t\t\t\t\t\t\t\t\t\t\t<a href=\"/blogdetails\" class=\"button small next\">Read Blog</a>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</header>
\t\t\t\t\t\t\t\t</article>
\t\t\t\t\t\t\t</section>

\t\t\t\t\t</div>

\t\t\t\t<!-- Footer -->
\t\t\t\t<footer id=\"footer\">
\t\t\t\t\t<div class=\"inner\">
\t\t\t\t\t\t<ul class=\"icons\">
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-twitter\"><span class=\"label\">Twitter</span></a></li>
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-facebook\"><span class=\"label\">Facebook</span></a></li>
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-instagram\"><span class=\"label\">Instagram</span></a></li>
\t\t\t\t\t\t\t<li><a href=\"#\" class=\"icon alt fa-linkedin\"><span class=\"label\">LinkedIn</span></a></li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t\t<ul class=\"copyright\">
\t\t\t\t\t\t\t<li>Copyright © 2020 Company Name - Template by:</li>
\t\t\t\t\t\t\t<li> <a href=\"https://www.phpjabbers.com/\">PHPJabbers.com</a></li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</footer>

\t\t\t</div>

\t\t<!-- Scripts -->
\t\t\t<script src=\"assets/js/jquery.min.js\"></script>
\t\t\t<script src=\"assets/bootstrap/js/bootstrap.bundle.min.js\"></script>
\t\t\t<script src=\"assets/js/jquery.scrolly.min.js\"></script>
\t\t\t<script src=\"assets/js/jquery.scrollex.min.js\"></script>
\t\t\t<script src=\"assets/js/browser.min.js\"></script>
\t\t\t<script src=\"assets/js/breakpoints.min.js\"></script>
\t\t\t<script src=\"assets/js/util.js\"></script>
\t\t\t<script src=\"assets/js/main.js\"></script>

\t</body>
</html>", "blog.html.twig", "D:\\wamp64\\www\\PI\\templates\\blog.html.twig");
    }
}
